#ifndef __PATH_H__ 
#define __PATH_H__ 
#define THE_FILE_PATH1 "t00.00.02" 
#define THE_FILE_PATH2 "compassboard" 
#endif //__PATH_H__ 
